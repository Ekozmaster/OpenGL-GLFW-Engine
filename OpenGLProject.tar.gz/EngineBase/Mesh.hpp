#include <vector>
class Mesh {
    private:
        std::vector<GLfloat> drawArray;
    public:
        std::vector<Vector3> vertices;
        int triangles[];
        Vector3 normals[];
        Mesh(Vector3 vertex[]){

        }

        Mesh(){

        }

        void UpdateMeshArrays(){
            int verticesCont = vertices.size();
            drawArray.resize(verticesCont*3);
            for(int i=0; i < verticesCont; i++){
                drawArray[i*3] = vertices[i].x;
                drawArray[i*3+1] = vertices[i].y;
                drawArray[i*3+2] = vertices[i].z;
            }
        }

        void Draw(){
            glEnableClientState(GL_VERTEX_ARRAY);
            glVertexPointer(3, GL_FLOAT, 0, &drawArray.front());
            glDrawArrays(GL_TRIANGLES, 0, drawArray.size());
            glDisableClientState(GL_VERTEX_ARRAY);
        }

        // Pass a array with a size of 108.
        static void BuildCubeArray(Vector3 pos, GLfloat *arrayToDraw){
            Vector3 face[] = {Vector3(-0.5, -0.5, -0.5),
                              Vector3(-0.5, 0.5, -0.5),
                              Vector3(0.5, 0.5, -0.5),
                              Vector3(-0.5, -0.5, -0.5),
                              Vector3(0.5, 0.5, -0.5),
                              Vector3(0.5, -0.5, -0.5)};

            //GLfloat drawArray[36*3];

            //Vector3 actualFace[6];
            for(int i=0; i < 6; i++){
                //actualFace[i] = Quaternion::Euler(0,0,0) * face[i];
                Vector3 vertex = Quaternion::Euler(Vector3(0,0,0)) * face[i];
                arrayToDraw[i*3] = pos.x + vertex.x;
                arrayToDraw[i*3+1] = pos.y + vertex.y;
                arrayToDraw[i*3+2] = pos.z + vertex.z;
            }
            for(int i=6; i < 12; i++){
                //actualFace[i] = Quaternion::Euler(0,0,0) * face[i];
                Vector3 vertex = Quaternion::Euler(Vector3(0,90,0)) * face[i%6];
                arrayToDraw[i*3] = pos.x + vertex.x;
                arrayToDraw[i*3+1] = pos.y + vertex.y;
                arrayToDraw[i*3+2] = pos.z + vertex.z;
            }
            for(int i=12; i < 18; i++){
                //actualFace[i] = Quaternion::Euler(0,0,0) * face[i];
                Vector3 vertex = Quaternion::Euler(Vector3(0,180,0)) * face[i%6];
                arrayToDraw[i*3] = pos.x + vertex.x;
                arrayToDraw[i*3+1] = pos.y + vertex.y;
                arrayToDraw[i*3+2] = pos.z + vertex.z;
            }
            for(int i=18; i < 24; i++){
                //actualFace[i] = Quaternion::Euler(0,0,0) * face[i];
                Vector3 vertex = Quaternion::Euler(Vector3(0,-90,0)) * face[i%6];
                arrayToDraw[i*3] = pos.x + vertex.x;
                arrayToDraw[i*3+1] = pos.y + vertex.y;
                arrayToDraw[i*3+2] = pos.z + vertex.z;
            }
            for(int i=24; i < 30; i++){
                //actualFace[i] = Quaternion::Euler(0,0,0) * face[i];
                Vector3 vertex = Quaternion::Euler(Vector3(90,0,0)) * face[i%6];
                arrayToDraw[i*3] = pos.x + vertex.x;
                arrayToDraw[i*3+1] = pos.y + vertex.y;
                arrayToDraw[i*3+2] = pos.z + vertex.z;
            }
            for(int i=30; i < 36; i++){
                //actualFace[i] = Quaternion::Euler(0,0,0) * face[i];
                Vector3 vertex = Quaternion::Euler(Vector3(-90,0,0)) * face[i%6];
                arrayToDraw[i*3] = pos.x + vertex.x;
                arrayToDraw[i*3+1] = pos.y + vertex.y;
                arrayToDraw[i*3+2] = pos.z + vertex.z;
            }
        }
};
