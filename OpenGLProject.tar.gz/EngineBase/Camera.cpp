#include"Camera.hpp"

Camera::Camera(Vector3 eye, Vector3 refPos, Vector3 upPose){
    eyePose = eye;
    pivotPoint = refPos;
    upDirection = upPose;
};

Camera::Camera(){
    eyePose = Vector3::zero();
    pivotPoint = Vector3::back();
    upDirection = Vector3::up();
};

