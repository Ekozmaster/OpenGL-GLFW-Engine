#include"GameObject.hpp";
Transform::Transform(Vector3 POS, Quaternion ROT, Vector3 SCL){
    position = POS;
    rotation = ROT;
    scale = SCL;
};

Transform::Transform(){
    position = Vector3::zero();
    rotation = Quaternion::identity();
    scale = Vector3::one();
};

GameObject::GameObject(){
    transform = Transform();
};

void GameObject::updateCamera(){
    Vector3 pivotPoint = (transform.rotation * Vector3::forward());
    cam.eyePose = transform.position;
    cam.pivotPoint = pivotPoint;
};
