//#define ESSENTIALS_HPP
#include<math.h>
#include "Vector3.hpp"
#include "Quaternion.hpp"
#include "Camera.hpp"
//#include "Mesh.hpp"
#include "GameObject.hpp"
#include "LookupTables.hpp"
#include "Mathf.hpp"
#include "Input.hpp"
#include "Window.hpp"
