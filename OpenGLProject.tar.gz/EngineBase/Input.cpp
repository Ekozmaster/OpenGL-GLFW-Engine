#include"Input.hpp"
// Input class can handle 4 keys at same time.


Input::Input(Vector3 screen_size){
    screenSize = screen_size;
};

void Input::Update(){
    int currentMouseX=0;
    int currentMouseY=0;
    Uint8 r = SDL_GetMouseState(&currentMouseX, &currentMouseY);
    deltaMouseX = currentMouseX - screenSize.x/2;
    deltaMouseY = currentMouseY - screenSize.y/2;

    AxisLogic(GetKey(Keycode::W), GetKey(Keycode::S), GetKey(Keycode::A), GetKey(Keycode::D));
};

void Input::AxisLogic(bool up, bool down, bool left, bool right){
    // VerticalAxis
    if(up){
        verticalAxis += axisAcceleration;
    } else if (down){
        verticalAxis -= axisAcceleration;
    } else {
        if(Mathf::Abs(verticalAxis) > axisAcceleration-0.01){
            verticalAxis += (-verticalAxis / Mathf::Abs(verticalAxis))*axisAcceleration;
        } else {verticalAxis = 0;}
    }

    // HorizontalAxis
    if(left){
        horizontalAxis -= axisAcceleration;
    } else if (right){
        horizontalAxis += axisAcceleration;
    } else {
        if(Mathf::Abs(horizontalAxis) > axisAcceleration-0.01){
            horizontalAxis += (-horizontalAxis / Mathf::Abs(horizontalAxis))*axisAcceleration;
        } else {horizontalAxis = 0;}
    }
    verticalAxis = Mathf::Clamp(verticalAxis, -1, 1);
    horizontalAxis = Mathf::Clamp(horizontalAxis, -1, 1);
};

bool Input::GetKey(int keycode){
    if(keysState[keycode]){return true;}
    return false;
};
float Input::GetAxis(string axisName){

    if(axisName == "Mouse X"){
        return deltaMouseX;
    } if(axisName == "Mouse Y"){
        return deltaMouseY;
    } if(axisName == "Vertical"){
        return verticalAxis;
    } if(axisName == "Horizontal"){
        return horizontalAxis;
    } else {
        return 0;
    }
};

