#ifndef GAMEOBJECT_HPP
#define GAMEOBJECT_HPP

#include"Vector3.hpp"
#include"Quaternion.hpp"
#include"Camera.hpp"

class Transform {
    public:
        Vector3 position;
        Quaternion rotation;
        Vector3 scale;
        Transform(Vector3 POS, Quaternion ROT, Vector3 SCL);
        Transform();
};

class GameObject{
    public:
        Transform transform;
        GameObject();
        Camera cam;

        void updateCamera();
};
#endif
/*
class Transform{
    public:
        Vector3 position;
        Quaternion rotation;
        Vector3 scale;
        Transform(Vector3 POS, Quaternion ROT, Vector3 SCL){
            position = POS;
            rotation = ROT;
            scale = SCL;
        }

        Transform(){
            position = Vector3::zero();
            rotation = Quaternion::identity();
            scale = Vector3::one();
        }

};

#include<list>
class GameObject{
    public:
        Transform transform;
        GameObject(){
            transform = Transform();
        }
        Camera cam;

        void updateCamera(){
            Vector3 pivotPoint = (transform.rotation * Vector3::forward());
            cam.eyePose = &transform.position;
            cam.pivotPoint = &pivotPoint;
        }
};
*/
