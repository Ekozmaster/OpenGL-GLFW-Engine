#ifndef INPUT_HPP
#define INPUT_HPP

#include"Vector3.hpp"

struct Keycode{
    public:
        const static int A = SDLK_a;//38;
        const static int B = SDLK_b;//56;
        const static int C = SDLK_c;//54;
        const static int D = SDLK_d;//40;
        const static int E = SDLK_e;//26;
        const static int F = SDLK_f;//41;
        const static int G = SDLK_g;//42;
        const static int H = SDLK_h;//43;
        const static int I = SDLK_i;//31;
        const static int J = SDLK_j;//44;
        const static int K = SDLK_k;//45;
        const static int L = SDLK_l;//46;
        const static int M = SDLK_m;//58;
        const static int N = SDLK_n;//57;
        const static int O = SDLK_o;//32;
        const static int P = SDLK_p;//33;
        const static int Q = SDLK_q;//24;
        const static int R = SDLK_r;//27;
        const static int S = SDLK_s;//39;
        const static int T = SDLK_t;//28;
        const static int U = SDLK_u;//30;
        const static int V = SDLK_v;//55;
        const static int W = SDLK_w;//25;
        const static int X = SDLK_x;//53;
        const static int Y = SDLK_y;//29;
        const static int Z = SDLK_z;//52;

        const static int Up = SDLK_UP;
        const static int Down = SDLK_DOWN;
        const static int Left = SDLK_LEFT;
        const static int Right = SDLK_RIGHT;

        const static int Space = SDLK_SPACE;
        const static int LeftControl = SDLK_LCTRL;
        const static int RightControl = SDLK_RCTRL;
        const static int LeftShift = SDLK_LSHIFT;
        const static int RightShift = SDLK_RSHIFT;
        const static int LeftAlt = SDLK_LALT;
        const static int RightAlt = SDLK_RALT;
};

class Input{
    public:
        Input();
        Input(Vector3 screen_size);
        void Update();
        void AxisLogic(bool up, bool down, bool left, bool right);
        int GetKey(int keycode);
        float GetAxis(char axisName[]);
};
/*
// Input class can handle 4 keys at same time.
class Input{
    private:
        Uint8 *keysState = SDL_GetKeyState(NULL);
        int deltaMouseX=0;
        int deltaMouseY=0;

        float verticalAxis=0;
        float horizontalAxis=0;

        float axisAcceleration=0.05f;

        Vector3 screenSize;
    public:
        Input(){

        }

        Input(Vector3 screen_size){
            screenSize = screen_size;
        }
        void Update(){
            int currentMouseX=0;
            int currentMouseY=0;
            Uint8 r = SDL_GetMouseState(&currentMouseX, &currentMouseY);
            deltaMouseX = currentMouseX - screenSize.x/2;
            deltaMouseY = currentMouseY - screenSize.y/2;

            AxisLogic(GetKey(Keycode::W), GetKey(Keycode::S), GetKey(Keycode::A), GetKey(Keycode::D));

        }

        void AxisLogic(bool up, bool down, bool left, bool right){
            // VerticalAxis
            if(up){
                verticalAxis += axisAcceleration;
            } else if (down){
                verticalAxis -= axisAcceleration;
            } else {
                if(Mathf::Abs(verticalAxis) > axisAcceleration-0.01){
                    verticalAxis += (-verticalAxis / Mathf::Abs(verticalAxis))*axisAcceleration;
                } else {verticalAxis = 0;}
            }

            // HorizontalAxis
            if(left){
                horizontalAxis -= axisAcceleration;
            } else if (right){
                horizontalAxis += axisAcceleration;
            } else {
                if(Mathf::Abs(horizontalAxis) > axisAcceleration-0.01){
                    horizontalAxis += (-horizontalAxis / Mathf::Abs(horizontalAxis))*axisAcceleration;
                } else {horizontalAxis = 0;}
            }
            verticalAxis = Mathf::Clamp(verticalAxis, -1, 1);
            horizontalAxis = Mathf::Clamp(horizontalAxis, -1, 1);
        }

        bool GetKey(int keycode){
            if(keysState[keycode]){return true;}
            return false;
        }
        float GetAxis(string axisName){

            if(axisName == "Mouse X"){
                return deltaMouseX;
            } if(axisName == "Mouse Y"){
                return deltaMouseY;
            } if(axisName == "Vertical"){
                return verticalAxis;
            } if(axisName == "Horizontal"){
                return horizontalAxis;
            } else {
                return 0;
            }
        }
};
*/
#endif
