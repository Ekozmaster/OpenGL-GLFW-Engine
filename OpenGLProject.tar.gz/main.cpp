#include<stdio.h>
#include<stdlib.h>
#include<GL/gl.h>
#include<GL/glx.h>
#include<GL/glu.h>
#include<unistd.h>
#include<SDL/SDL.h>

#include "EngineBase/essentials.hpp"
#include "API/essentials.hpp"

GLint                   att[] = { GLX_RGBA, GLX_DEPTH_SIZE, 24, GLX_DOUBLEBUFFER, None };
Colormap                cmap;
GLXContext              glc;

Camera SetupNewCamera(){
    Vector3 eye = Vector3(0,0,0);
    Vector3 refP = Vector3(0, 0, 5);
    Vector3 upPose = Vector3(0, 1, 0);
    Camera cam = Camera(eye, refP, upPose);
    return cam;
}

int main(int argc, char *argv[]) {
    GameObject camera = GameObject();
    camera.cam = SetupNewCamera();
    camera.transform.position = Vector3(0,0,-5);
    camera.transform.rotation = Quaternion::Euler(Vector3::zero());
    WindowObject window = WindowObject(720, 480, camera);

    glEnable(GL_DEPTH_TEST);

    SDL_Event event;



    while(1) {
        window.MainFrame();

    }
    return 0;
}
